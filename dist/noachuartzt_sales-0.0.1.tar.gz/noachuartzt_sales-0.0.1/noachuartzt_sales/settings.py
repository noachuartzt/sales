DB_SETTINGS = {
    'host':'db',
    'user':'root',
    'password':'example',
    'database':'booking'
}

BaseManager.set_connection(DB_SETTINGS)